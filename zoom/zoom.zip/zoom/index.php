<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Effet de zoom avec CSS gr�ce en utilisant la pseudo-classe :hover</title>
<style type="text/css">
<!--
/*//////////////////////\\\\\\\\\\\\\\\\\\\\\
 CSStyled by br1o
 copytop, juillet 2006
\\\\\\\\\\\\\\\\\\\\\\\\////////////////////*/

body {
	margin: 0;
	padding: 0;
	font: 0.75em/140% Verdana, Arial, Helvetica, sans-serif;
	text-align: center;
	border-top: 25px solid #D1DF29;
	border-bottom: 25px solid #D1DF29;
}
#container {
	position: relative;
	margin: 0 auto;
	width: 50%;
	text-align: left;
}
h1 {
	font-size: 2em;
	line-height: 150%;
	margin: 0 0 1.5em 0;
	color: #C73A26;
}
h2 {
	font-size: 1.5em;
	line-height: 140%;
	color: #838A3C;
}
hr {
	clear: both;
	visibility: hidden;
}
p {
	color: #4F5762;
}
.content {
	margin: 0 0 0 60px;
	border-left: 10px solid #EFF6FF;
	padding: 0 0 0 15px;
}
.vignette a {
	position: absolute;
	display: block;
	width: 40px;
	height: 40px;
	margin: 0 1em 0 0;
	border: 1px solid #cecece;
}
.vignette a:hover {
	position: absolute;
	display: block;
	width: 180px;
	height: 180px;
	margin: 0 1em 0 0;
	border: 1px solid #cecece;
}
.tennis a {
	background: url(pix/tennis_boy.jpg) no-repeat top left;
}
.tennis a:hover {
	background: url(pix/tennis_boy.jpg) no-repeat bottom right;
}
.foot a {
	background: url(pix/foot_boy.jpg) no-repeat top left;
}
.foot a:hover {
	background: url(pix/foot_boy.jpg) no-repeat bottom right;
}

.foot2 a {
	background: url(pix/foot2_boy.jpg) no-repeat top left;
}
.foot2 a:hover {
	background: url(pix/foot2_boy.jpg) no-repeat bottom right;
}
-->
</style>
</head>

<body>
<div id="container">
	<h1>Lorem ipsum dolor sit amet</h1>
	<h2>Lorem ipsum dolor sit amet</h2>
	<div class="article">
		<p class="vignette tennis">
			<a href="#" title="zoom!"></a>
		</p>
		<div class="content">
			<p>
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, 
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, 
				sunt in culpa qui officia deserunt mollit anim id est laborum." 
			</p>
			<p>
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, 
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, 
				sunt in culpa qui officia deserunt mollit anim id est laborum." 
			</p>
		</div>
	</div>
	<hr />
	
	<h2>Lorem ipsum dolor sit amet</h2>
	<div class="article">
		<p class="vignette foot">
			<a href="#" title="zoom!"></a>
		</p>
		<div class="content">
			<p>
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, 
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, 
				sunt in culpa qui officia deserunt mollit anim id est laborum." 
			</p>
			<p>
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, 
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, 
				sunt in culpa qui officia deserunt mollit anim id est laborum." 
			</p>
		</div>
	</div>
	<hr />
	
	<h2>Lorem ipsum dolor sit amet</h2>
	<div class="article">
		<p class="vignette foot2">
			<a href="#" title="zoom!"></a>
		</p>
		<div class="content">
			<p>
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, 
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, 
				sunt in culpa qui officia deserunt mollit anim id est laborum." 
			</p>
			<p>
				"Lorem ipsum dolor sit amet, consectetur adipisicing elit, 
				sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
				Ut enim ad minim veniam, 
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
				Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
				Excepteur sint occaecat cupidatat non proident, 
				sunt in culpa qui officia deserunt mollit anim id est laborum." 
			</p>
		</div>
	</div>
	<hr />
</div>
</body>
</html>
