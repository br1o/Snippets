<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15" />
<title>formulaire css</title>
<style type="text/css">
<!--
/*//////////////////////\\\\\\\\\\\\\\\\\\\\\
 CSStyled by br1o
 copytop, juillet 2006
\\\\\\\\\\\\\\\\\\\\\\\\////////////////////*/

/* Layout globals */

body {
	margin: 2em 0 0 0;
	padding: 0;
	text-align: center;
	font: 0.75em/1.2em Verdana, Arial, Helvetica, sans-serif;
	color: #666;
}
body * {
	margin: 0;
	padding: 0;
}
#full {
	position: relative;
	width: 60%;
	margin: 0 auto;
	text-align: left;
}

/* Layout frame */

#topRight, #bottomRight {
	float: right;
}
#topRight {
	background: transparent url(pix/top_right.gif) no-repeat;
}
#bottomRight {
	background: transparent url(pix/bottom_right.gif) no-repeat;
}
#topLeft, #topRight, #bottomLeft, #bottomRight {
	width: 32px;
	height: 32px;
}
#topLeft {
	background: transparent url(pix/top_left.gif) no-repeat;
}
#bottomLeft {
	background: transparent url(pix/bottom_left.gif) no-repeat;
}
#sideLeft {
	background: transparent url(pix/side_left.gif) top left repeat-y;
}
#sideRight {
	background: transparent url(pix/side_right.gif) top right repeat-y;
}
.sideTop, .sideBottom {
	width: auto;
	height: 32px;
}
#sideTop {
	background: transparent url(pix/side_top.gif) repeat-x;
}
#sideBottom {
	background: transparent url(pix/side_bottom.gif) repeat-x;
}

/* layout content */

.content {
	padding: 1em 3em;
}
.content p {
	margin-bottom: 0.5em;
	line-height: 1.3em
}
h1 {
	font-size: 1.5em;
	margin: 0 0 1em 0;
	color: #FFD100;
	letter-spacing: -0.05em;
}
hr {
	clear: both;
	visibility: hidden;
	height: 0.1em;
	border: 0;
}
ul {
	margin: 0 0 0 3em;
	list-style-type: square;
}
ul li {
	margin: 0 0 0.5em 0;
}
a {
	text-decoration: none;
}
a:hover {
	text-decoration: underline;
}
-->
</style>
</head>
<body>
	<div id="full">
		<div id="sideTop">
			<div id="topRight"></div><div id="topLeft"></div>
		</div>
		<div id="sideRight">
		  <div id="sideLeft" class="content">
			<!-- CONTENT START HERE -->
				<h1><a href="http://www.css4design.com/blog/index.php/2006/06/13/6-design-css-fixe-elastique-ou-liquide" title="Votre mise en pages CSS : fixe, �lastique ou liquide" alt="Votre mise en pages CSS : fixe, �lastique ou liquide">"Votre mise en pages CSS : fixe, �lastique ou liquide ?</a></h1>
				<p>Difficile,  en effet, de choisir la bonne formule pour ses mises en pages CSS.  Surtout si l&rsquo;on se pr&eacute;ocuppe des standards web et des bonnes mani&egrave;res  pour un web qui prenne du sens et perde du poids ! bon, ne nous  emballons pas et entrons dans le vif du sujet en pr&eacute;cisant rapidement  de quoi il s&rsquo;agit :</p>
				<ul>
                  <li>Fixe, votre design poss&egrave;de une largeur fixe exprim&eacute;e le plus  souvent en pixels. Elle ne change pas, et ce, quel que soit la  taille/r&eacute;solution de l&rsquo;&eacute;cran du visiteur.</li>
				  <li>Elastique, votre design semble fixe, mais peut supporter une  augmentation plus ou moins importante de la taille du texte sans que  votre design en souffre trop.</li>
				  <li>Liquide, la largeur de votre design est exprim&eacute;e plut&ocirc;t en  pourcentage et s&rsquo;adapte &agrave; la taille de la fen&ecirc;tre du navigateur. Cette  derni&egrave;re solution va retenir notre attention, car c&rsquo;est &ccedil;a le web : on  s&rsquo;adapte &agrave; l&rsquo;internaute et pas l&rsquo;inverse&hellip; J&rsquo;en vois au fond qui  soupirent, mais bon, un peu de bon sens n&rsquo;a jamais fait de mal &agrave;  personne.</li>
		    </ul>
				<p>Si la conception d&rsquo;un design fixe avec en-t&ecirc;te, pied de page et  bordures de chaque c&ocirc;t&eacute; est simple &agrave; r&eacute;aliser en CSS, il n&rsquo;en va pas  toujours de m&ecirc;me pour un design liquide. Notamment lorsqu&rsquo;on veut  mettre des images partout. Souvent, le designer finit pas jeter  l&rsquo;&eacute;ponge et retourne vers le c&ocirc;t&eacute; obscur. Et voil&agrave; que les balises TR  et TD poussent comme des champignons apr&egrave;s la pluie.</p>
				<p>Le beau temps, c&rsquo;est vers les CSS et une organisation judicieuse de  notre code (x)html que nous allons le trouver. Car, pratique en  apparence, les tableaux, et bien, c&rsquo;est pas bien, et cel&agrave; pour plein de  raisons, que d&rsquo;autres, <a target="_blank" title="Tableaux contre css : un combat &agrave; mort" href="http://www.sitepoint.com/article/tables-vs-css">ici en anglais</a> ou encore <a title="Tableaux vs CSS : un combat &agrave; mort" target="_blank" href="http://pompage.net/pompe/tablevscss/">l&agrave; en fran&ccedil;ais</a>, vous expliquerons mieux que moi.</p>
				<p>L&rsquo;objectif est d&rsquo;obtenir une structure souple qui permette  d&rsquo;accueillir tous les d&eacute;lires de votre graphiste. Vous savez, le gars  un peu sauvage (mais sympa) qui vous dit souvent qu&rsquo;avec les tableaux,  c&rsquo;&eacute;tait mieux avant ! J&rsquo;ai voulu aussi une structure simple pour que  les d&eacute;veloppeurs (vous savez les gars un peu&hellip; bizarre, quoi&hellip;) ne  perdent pas leur pr&eacute;cieux temps avec toutes ces satan&eacute;s balises TABLE  TR TD.</p>
				<p>Voici donc le design compos&eacute; de quatre coins, de deux bordures  verticales, et pourquoi pas, soyons fous, de deux bordure horizontales.  Test&eacute; sur Windows, sur Mac et sur les principaux navigateurs r&eacute;cents.  Et sans hack. Non pas que je n&rsquo;en utilise pas parfois, mais bon, pour  une structure r&eacute;utilisable c&rsquo;e&ucirc;t &eacute;t&eacute; une faute de go&ucirc;t. Enjoy.</p>
			  <!-- CONTENT ENDS HERE -->
            </div>
		</div>
		<div id="sideBottom">
			<div id="bottomRight"></div><div id="bottomLeft"></div>
		</div>
		<p><a href="http://www.css4design.com/blog/index.php/2006/06/13/6-design-css-fixe-elastique-ou-liquide">Retour vers l'article</a></p>
	</div>
</body>
</html>
